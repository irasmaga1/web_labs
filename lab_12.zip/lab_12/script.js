//task 1
alert("hello");

//task 2
console.log("Smaha");

//task 3
let a = 5;
let b = 6;
console.log(a, b);
a = b;
console.log(a, b);

//task 4
let person = {
    name: "Iryna",
    age: 18,
    isStudent: true,
    life: undefined,
    money: null
};
console.log(person);

//task 5
let isAdult = confirm("Ви досягли повнолітнього віку?");
console.log("Ваш вік: ", isAdult);

//task 6
let firstName = "Iryna";
let surname = "Smaha";
let group = "CS-323";
let birthAge = 2005;
let maritalSatus = true;

console.log(typeof firstName);
console.log(typeof surname);
console.log(typeof group);
console.log(typeof birthAge);
console.log(typeof maritalSatus);

console.log(birthAge + "\n" + maritalSatus + "\n" + firstName + "\n" + surname + "\n" + group);

let Null1 = null;
let Undefined1 = undefined;

console.log(typeof Null1);
console.log(typeof Undefined1);


//task 7
let questionLogin = prompt("Enter login");
let questionEmail = prompt("Enter email");
let questionPassword = prompt("Enter password");

let answer = alert("Dear " + questionLogin + ", your email is " + questionEmail + ", your password is "+ questionPassword);


// task 8
const secondInHour = 60**2;
const secondInDay = secondInHour**2;
const secondInMonth = secondInDay*30;

console.log(secondInHour + "second.");
console.log(secondInDay + "second.");
console.log(secondInMonth + "second.");
