export const SendMassege = () =>{
    console.log("Hello from enotherJS.js")
}