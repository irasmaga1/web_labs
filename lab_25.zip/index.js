const {SendMassege} = require("./enother.js")


SendMassege()