import  {SendMassege}  from "./enotherJS.js";


SendMassege()