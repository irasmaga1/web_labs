const SendMassege = () =>{
    console.log("Hello from enother.js")
}

module.exports = {SendMassege}
